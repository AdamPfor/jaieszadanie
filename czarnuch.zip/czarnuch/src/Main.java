import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        String sciezka = "";
        File plik = new File(sciezka);

        if (!plik.exists()) {
            System.out.println("Nie znaleziono pliku liczby.txt");
            return;
        }

        int count = 0;
        String candidate = null;

        try {
            FileReader file = new FileReader(plik);
            BufferedReader reader = new BufferedReader(file);

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.charAt(0) == line.charAt(line.length() - 1)) {
                    count++;
                    if (candidate == null) {
                        candidate = line;
                    }
                }
            }

            reader.close();
        } catch (IOException e) {
            System.out.println("Błąd odczytu pliku liczby.txt");
            return;
        }

        System.out.println("Liczba liczb, których cyfry pierwsza i ostatnia są takie same: " + count);
        System.out.println("Pierwsza taka liczba: " + candidate);
    }
}


